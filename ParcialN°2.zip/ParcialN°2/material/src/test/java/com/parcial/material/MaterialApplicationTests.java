package com.parcial.material;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialApplicationTests {

	@Test
	void contextLoads() {
	}

}
