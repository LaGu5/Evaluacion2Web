package com.parcial.venta.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.parcial.venta.model.Venta;
import com.parcial.venta.service.IVentaService;

@RestController
@RequestMapping("/api/phoenix_dinamic/venta")
public class VentaController {
	@Autowired
	private IVentaService service;
	
	@GetMapping("/getAll")
	public List<Venta> obtenerTodos(){
		return service.findAll();
	}
	
	@GetMapping("/get/{id}")
	public Venta obtenerPorId(@PathVariable("id")Long id) {
		return service.findById(id);
	}
	
	@PostMapping("/save")
	public Venta registrarVenta(@RequestBody Venta venta) {
		venta.setFecha_compra(LocalDate.now());
		service.save(venta);
		return venta;
	}
	@PutMapping("/actualizar/{id}")
	public Venta actualizarDatos(@PathVariable("id")Long id,@RequestBody Venta v) {
		Venta venta=service.findById(id);
		venta.setEstado(v.getEstado());
		return venta;
	}
	@DeleteMapping("/delete/{id}")
	public Venta eliminarPorId(@PathVariable("id") Long id) {
		Venta v=service.findById(id);
		service.deleteById(id);
		return v;
	}
	
}
