package com.parcial.venta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.parcial.venta.model.Venta;
import com.parcial.venta.repository.IVentaRepository;

@Service
public class VentaServiceImpl implements IVentaService{

	@Autowired
	private IVentaRepository repository;
	@Override
	public List<Venta> findAll() {
		return repository.findAll();
	}

	@Override
	public Venta findById(Long id) {
		return repository.findById(id).orElseThrow();
	}

	@Override
	public void save(Venta venta) {
		repository.save(venta);
		
	}

	@Override
	public void deleteById(Long id) {
		repository.deleteById(id);
		
	}
	
}
