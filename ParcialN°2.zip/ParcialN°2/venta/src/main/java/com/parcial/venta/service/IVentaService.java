package com.parcial.venta.service;

import java.util.List;

import com.parcial.venta.model.Venta;

public interface IVentaService {
	List<Venta> findAll();
	Venta findById(Long id);
	void save(Venta venta);
	void deleteById(Long id);
}
