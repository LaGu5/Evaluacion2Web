package com.parcial.envio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnvioApplicationTests {

	@Test
	void contextLoads() {
	}

}
