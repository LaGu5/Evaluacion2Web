package com.parcial.envio.service;

import java.util.List;

import com.parcial.envio.model.Envio;

public interface IEnvioService {
	List<Envio> findAll();
	Envio findById(Long id);
	void save(Envio envio);
	void deleteById(Long id);
}
