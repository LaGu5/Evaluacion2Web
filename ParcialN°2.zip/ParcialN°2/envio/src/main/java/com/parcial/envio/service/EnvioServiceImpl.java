package com.parcial.envio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.parcial.envio.model.Envio;
import com.parcial.envio.repository.IEnvioRepository;

@Service
public class EnvioServiceImpl implements IEnvioService {
	@Autowired
	private IEnvioRepository repository;
	
	@Override
	public List<Envio> findAll() {
		return repository.findAll();
	}

	@Override
	public Envio findById(Long id) {
		return repository.findById(id).orElseThrow();
	}

	@Override
	public void save(Envio envio) {
		repository.save(envio);
	}

	@Override
	public void deleteById(Long id) {
		repository.deleteById(id);

	}

}
