package com.parcial.envio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.parcial.envio.model.Envio;
import com.parcial.envio.service.IEnvioService;

@RestController
@RequestMapping("/api/phoenix_dinamic/envio")
public class EnvioController {
	@Autowired
	private IEnvioService service;
	
	@GetMapping("/findAll")
	public List<Envio> obtenerTodos(){
		return service.findAll();
	}
	@GetMapping("/findById/{id}")
	public Envio obtenerPorId(@PathVariable("id") Long id){
		return service.findById(id);
	}
	@PostMapping("/save")
	public Envio crearEnvio(@RequestBody Envio envio) {
		service.save(envio);
		return envio;
	}
	@PutMapping("/actualizar/{id}")
	public Envio actualizarEnvio(@PathVariable("id") Long id, @RequestBody Envio e) {
		Envio envio= service.findById(id);
		envio.setEstado(e.getEstado());
		envio.setFecha_estimada_entrega(e.getFecha_estimada_entrega());
		service.save(envio);
		return e;
	}
	@DeleteMapping("/delete/{id}")
	public Envio eliminarPorId(@PathVariable("id") Long id) {
		Envio envio=service.findById(id);
		service.deleteById(id);
		return envio;
	}
}
