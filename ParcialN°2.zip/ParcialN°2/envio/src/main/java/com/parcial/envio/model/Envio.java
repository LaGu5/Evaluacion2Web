package com.parcial.envio.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "envio")
public class Envio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_envio;
	private Long id_venta;
	private String estado;
	private LocalDate fecha_despacho;
	private LocalDate fecha_estimada_entrega;
	
}
