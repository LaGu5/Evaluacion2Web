package com.parcial.org_persona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrgPersonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
